# Inform the user what the script does
print("Count to 10!")

# Use a for loop to count from 0 to 10
for x in range(0, 11):
    print(x)
